/**
 * Resource Constrained Shortest Path Solver
 * Designed to be used by Branch-Cut-and-Price algorithms
 *
 * Includes also
 * - k-path cut separation (rounded capacity cuts and 2-path cuts, both weak and limited-memory strong versions)
 * - limited-memory packing and covering rank-1 cuts separation (up to eight rows)
 * - route load knapsack cuts separation (by rounding and by enumeration of 1/6-, 1/8-, and 1/10-inequalities)
 * - packing set-based Ryan&Foster branching constraints separation
 * - accumulated resource consumption branching constraints separation
 *
 * @author Ruslan Sadykov <Ruslan.Sadykov@inria.fr>, Inria Bordeaux, France (coordinator and main contributor)
 * @author Eduardo Uchoa <eduardo.uchoa@gmail.com>, UFF, Brazil (scientific advise)
 * @author Artur Alves Pessoa <artur.a.pessoa@gmail.com> UFF, Brazil (scientific advise and rank-1 cuts separation)
 * @author Teobaldo Bulhões <teojuniorpb@gmail.com> UFPB, Brazil (rank-1 cuts separation)
 * @author Isaac Balster <Isaac.Balster@inria.fr>, Inria Bordeaux, France (k-path cuts separation)
 * @author Aurelien Froger <aurelien.froger@u-bordeaux.fr>, University of Bordeaux, France (scientific advise)
 * @author Eduardo Queiroga <eduardovqueiroga@gmail.com>, Inria Bordeaux, France (pair of base-dependent resoureces
 *                                                                                in the meta-solver)
 *
 * Inria Centre at the University of Bordeaux, France, All Rights Reserved. [LICENCE]
 *
 */

#ifndef RCSP_INTERFACE_HPP_
#define RCSP_INTERFACE_HPP_

#include "rcsp_data.hpp"
#include <set>
#include <utility>
#include <vector>
#include <map>
#include <unordered_map>
#include <cmath>

namespace bcp_rcsp {

/// Attention! Compilation flags should not be changed unless you can recompile the RCSP library.

#define SET_PACKING_CUT 0
#define SET_COVERING_CUT 1
#define SET_PACKING_CUT_ON_COVERING_SETS 2

#define VERTEX_MEMORY_TYPE 0
#define ARC_MEMORY_TYPE 1
#define FULL_MEMORY_TYPE 2

#define GREATER_OR_EQUAL_SENSE 0
#define LESS_OR_EQUAL_SENSE 1

/// values for the "enumerationMode" argument below
#define NO_ENUMERATION (-1)
#define STANDARD_ENUMERATION 0
#define ENUMERATION_FOR_HEURISTIC 1

    struct Solution
    {
        int graphId;
        bool enumeratedFlag;
        double pureArcCost;
        std::vector<int> arcIds; /// arc ids of the path
        std::vector<std::vector<double> > resConsumption;
        std::vector<double> waitingTimes;
        std::vector<std::pair<int, int>> selectedValues; /// pairs (selection resource id, a [cheapest] feasible value)

        explicit Solution(int graphId_) :
                graphId(graphId_), enumeratedFlag(false), pureArcCost(0.0), arcIds(), resConsumption(), waitingTimes(),
                selectedValues()
        {}

        explicit Solution (const Solution * thatSolPtr) :
                graphId(thatSolPtr->graphId), enumeratedFlag(thatSolPtr->enumeratedFlag),
                pureArcCost(thatSolPtr->pureArcCost), arcIds(thatSolPtr->arcIds),
                resConsumption(thatSolPtr->resConsumption), waitingTimes(thatSolPtr->waitingTimes),
                selectedValues(thatSolPtr->selectedValues)
        {}
    };

    struct FractionalMasterSolution
    {
        std::vector<const Solution *> solPts;
        std::vector<double> values;

        FractionalMasterSolution() : solPts(), values()
        {}
    };

    struct RoundedCapacityCut
    {
        int id;
        int sense; /// GREATER_OR_EQUAL_SENSE or LESS_OR_EQUAL_SENSE
        int rhs;
        std::vector<int> setIds;
        std::vector<std::tuple<int, int, double> > varsMembership; /// triples of <id, varId, coeff>

        RoundedCapacityCut(int id_, int sense_, int rhs_, std::vector<int> setIds_) :
                id(id_), sense(sense_), rhs(rhs_), setIds(std::move(setIds_)), varsMembership()
        {}
    };

    class RoundCapCutSeparationInterface
    {
    protected :
        RoundCapCutSeparationInterface() = default;
    public :
        virtual ~RoundCapCutSeparationInterface() = default;

        /// Finds at most maxNumCuts of violated cuts
        /// returns false if an error occured during separation
        virtual bool separate(const FractionalMasterSolution & fracMasterSol,
                              std::vector<const RoundedCapacityCut *> & cutPts) = 0;
    };

    /// Creates and prepares rounded capacity cut separation. Returns nullptr if an error occured.
    RoundCapCutSeparationInterface * createAndPrepareRoundCapCutSeparation(const std::vector<const GraphData *> & graphs,
                                                                           const std::vector<double> & demands,
                                                                           double capacity, int twoPathCutsResId,
                                                                           RoundCapCutsSeparatorParameters params);

    struct StrongKPathCut
    {
        int id;
        double rightHandSide;
        std::vector<int> setIds;
        int memoryType; /// VERTEX_MEMORY_TYPE or ARC_MEMORY_TYPE
        std::unordered_map<int, std::set<int> > graphIdToMemorySet;

        StrongKPathCut(int id_, double rhs_, std::vector<int> setIds_, int memoryType_) :
                id(id_), rightHandSide(rhs_), setIds(std::move(setIds_)), memoryType(memoryType_),
                graphIdToMemorySet()
        {}
    };

    class StrongKPathCutSeparationInterface
    {
    protected :
        StrongKPathCutSeparationInterface() = default;
    public :
        virtual ~StrongKPathCutSeparationInterface() = default;

        /// Finds at most maxNumCuts of violated cuts
        /// returns false if an error occured during separation
        virtual bool separate(const FractionalMasterSolution & fracMasterSol,
                              std::vector<const StrongKPathCut *> & strongCutPts) = 0;

        /// Calculates the coefficient of the column corresponding to the path in the cut constraint
        virtual double coefficient(const Solution * solPtr, const StrongKPathCut * cutPtr) const = 0;

        virtual void niceCutPrint(const StrongKPathCut * cutPtr, std::ostream & os) const = 0;
    };

    /// Creates and prepares strong k-path cut separation. Returns nullptr if an error occurred.
    StrongKPathCutSeparationInterface *
        createAndPrepareStrongKPathCutSeparation(const std::vector<const GraphData *> & graphs,
                                                 const std::vector<double> & demands,
                                                 double capacity, int twoPathCutsResId,
                                                 StrongKPathSeparatorParameters params);

    struct RankOneCut
    {
        int id;
        double rightHandSide;
        int cutClass; /// SET_PACKING_CUT or SET_COVERING_CUT or SET_PACKING_CUT_ON_COVERING_SETS
        int numRows;
        int fiveOrMoreRowsType;
        int denominator;
        std::vector<int> coeffs; /// for packing cuts, coeffs and denominator are positive,
                                 /// for covering cuts, coeffs and denominator are negative
        std::vector<int> setIds;
        int memoryType; /// VERTEX_MEMORY_TYPE or ARC_MEMORY_TYPE
        std::unordered_map<int, std::set<int> > graphIdToMemorySet;

        RankOneCut(int id_, double rhs_, int cutClass_, int numRows_, int fiveOrMoreRowsType_,
                   int denominator_, std::vector<int> coeffs_, std::vector<int> setIds_, int memoryType_) :
                id(id_), rightHandSide(rhs_), cutClass(cutClass_), numRows(numRows_),
                fiveOrMoreRowsType(fiveOrMoreRowsType_), denominator(denominator_), coeffs(std::move(coeffs_)),
                setIds(std::move(setIds_)), memoryType(memoryType_), graphIdToMemorySet()
        {}
    };

    struct RankOneCutSeparationInput
    {
        FractionalMasterSolution fracMasterSol;
        std::string solutionFile;
        int memoryTypeForThisRound;
        bool arcIdsInPathsArePackSetIds;
        int phase;
        std::vector<std::pair<const RankOneCut *, double> > rankOneCuts;

        RankOneCutSeparationInput() :
                fracMasterSol(), memoryTypeForThisRound(VERTEX_MEMORY_TYPE), arcIdsInPathsArePackSetIds(false),
                phase(1), rankOneCuts()
        {}
    };

    class RankOneCutSeparationInterface
    {
    protected :
        RankOneCutSeparationInterface() = default;
    public :
        virtual ~RankOneCutSeparationInterface() = default;

        /// Finds at most maxNumCuts of violated cuts
        /// returns false if an error occured during separation
        virtual bool separate(const RankOneCutSeparationInput & input,
                              std::vector<const RankOneCut *> & cutPts) = 0;

        /// Calculates the coefficient of the column corresponding to the path in the cut constraint
        virtual double coefficient(const Solution * solPtr, const RankOneCut * cutPtr) const = 0;

        virtual void niceCutPrint(const RankOneCut * cutPtr, std::ostream & os) const = 0;
    };

    /// Creates and prepares rank one cut separation. Returns nullptr if an error occured.
    RankOneCutSeparationInterface * createAndPrepareRankOneCutSeparation(const std::vector<const GraphData *> & graphs,
                                                                         LimMemRankOneCutsSeparatorParameters params);

    struct RouteLoadKnapsackCut
    {
        int id;
        int origConstrId;
        int rightHandSide;
        int oneKvalue; /// needed for stats
                       /// 0 if separated as a Fenchel cut (this separation is not implemented by the RCSP solver)
                       /// 1 if separated by Rounding
                       /// k>=2 if separated as a 1/k-inequality by Chopra et al. method
        std::map<int, std::pair<int, double> > resVariableMap; /// graph Id -> (resource Id, resource var. coeff.)
        std::map<int, int> coeffMap;

        RouteLoadKnapsackCut(int id_, int origConstrId_, int rhs_, int oneKvalue_,
                             std::map<int, std::pair<int, double> > resVariableMap_, std::map<int, int> coeffMap_) :
                id(id_), origConstrId(origConstrId_), rightHandSide(rhs_), oneKvalue(oneKvalue_),
                resVariableMap(std::move(resVariableMap_)), coeffMap(std::move(coeffMap_))
        {}
        void nicePrint(std::ostream & os) const;
    };

    struct RouteLoadKnapsackCutSeparationInput
    {
        FractionalMasterSolution fracMasterSol;
        /// map orig.constr.id => (master knapsack map, rightHandSide),
        /// where master knapsack map is map (item weight => item var. value)
        std::map<int, std::pair<std::map<int, double>, int> > pureMasterVarsInfos;

        RouteLoadKnapsackCutSeparationInput(FractionalMasterSolution fracMasterSol_,
                                            std::map<int, std::pair<std::map<int, double>, int> > pureMasterVarsInfos_) :
                fracMasterSol(std::move(fracMasterSol_)), pureMasterVarsInfos(std::move(pureMasterVarsInfos_))
        {}
    };

    class RouteLoadKnapsackCutSeparationInterface
    {
    protected :
        RouteLoadKnapsackCutSeparationInterface() = default;
    public :
        virtual ~RouteLoadKnapsackCutSeparationInterface() = default;

        /// Finds at most maxNumCuts of violated cuts
        /// rightHandSide value of the original knapsack constraint may change
        /// (depending on the fixed pure master variables after preprocessing or branching),
        /// therefore we communicate this value directly to the separation routine (and not while preparing)
        /// returns false if an error occured during separation
        virtual bool separate(const RouteLoadKnapsackCutSeparationInput & input,
                              std::vector<const RouteLoadKnapsackCut *> & routeLoadKnapCutPts) = 0;

        /// Calculates the coefficient of the column corresponding to the path in the cut constraint
        virtual double coefficient(const Solution * solPtr, const RouteLoadKnapsackCut * cutPtr) const = 0;
    };

    /// every element of this vector corresponds to one original knapsack constraint
    /// every element in the map is a pair
    ///     Graph=>(resource id, coeff. of var. associated with this resource in the orignal knapsack constraint)
    typedef std::vector<std::map<const GraphData *, std::pair<int, double> > > ResourceVarMapVector;

    /// Creates and prepares route load knapsack cuts separation. Returns nullptr if an error occured.
    RouteLoadKnapsackCutSeparationInterface * createAndPrepareRouteLoadKnapsackCutSeparation(
            const ResourceVarMapVector & resourceVarMaps, RouteLoadKnapsackCutsSeparatorParameters params);

    /// Clique cuts are not separated by the RCSP solver, this interface is here only
    /// to support clique cuts, separated in BaPCod
    class CliqueCutInterface
    {
    public:
        CliqueCutInterface() = default;
        virtual ~CliqueCutInterface() = default;
        virtual const std::vector<std::vector<int> > & setIds() const = 0;
        virtual int id() const = 0;
        virtual void nicePrint() const = 0;
    };

    /// Discrete cuts are not separated by the RCSP solver, this interface is here only
    /// to support discrete cuts, separated in BaPCod
    class DiscreteCutInterface
    {
    public:
        DiscreteCutInterface() = default;
        virtual ~DiscreteCutInterface() = default;
        virtual DiscreteCutInterface * createCopy() const = 0;
        virtual int id() const = 0;
        virtual void nicePrint() const = 0;
        virtual bool customCut() const = 0;
        virtual double getArcCoefficient(const int & tailId, const int & headId, const double * tailResCons) const = 0;
        virtual double getArcCoefficient(const int & arcId, const double * resCons,
                                         const bool & isTailResCons) const = 0;
        virtual double getVertRouteCoefficient(const std::vector<int> & routeVertIds,
                                               const std::vector<std::vector<double> > & routeResCons) const = 0;
        virtual double getArcRouteCoefficient(const std::vector<int> & routeArcIds,
                                              const std::vector<std::vector<double> > & routeResCons) const = 0;
        virtual void reserveCut() const = 0;
        virtual void releaseCut() const = 0;
    };

    struct SolverInput {
        double zeroRedCostThreshold;
        double fixingThreshold;
        int colGenPhase;
        bool rollbackStateIsSaved;
        bool checkDebugSolution;
        std::vector<double> varRedCosts; /// varId to reduced cost
        std::vector<std::pair<const RankOneCut *, double> > rankOneCuts;
        std::vector<std::pair<const DiscreteCutInterface *, double> > discreteCuts;
        std::vector<std::pair<const RouteLoadKnapsackCut *, double> > routeLoadKnapCuts;
        std::vector<std::pair<const CliqueCutInterface *, double> > cliqueCuts;
        std::vector<std::pair<const StrongKPathCut *, double> > strongKPathCuts;

        explicit SolverInput(const int numVars) :
                zeroRedCostThreshold(RCSP_INFINITY), fixingThreshold(RCSP_INFINITY), colGenPhase(0),
                rollbackStateIsSaved(false), checkDebugSolution(false), varRedCosts(numVars, 0.0), rankOneCuts(),
                discreteCuts(), routeLoadKnapCuts(), cliqueCuts()
        {}
    };


    struct SolverOutput
    {
        bool shouldPerformRollback; /// rollback should be performed if a hard time limit is reached or
                                    /// if too many rank-1 cuts are active (no space for rank-1 cuts information)
        double bestSolutionCost; /// equal to RCSP_INFINITY if no paths are found
        std::vector<Solution *> solPts; /// ownership of pointers belongs to SolverOutput, you should either
                                        /// pass the ownership somewhere or call path destructor for every path

        SolverOutput() :
                shouldPerformRollback(false), bestSolutionCost(0.0), solPts()
        {}
    };

    struct AccumResConsBranchGenerator {
        int packSetId;
        int resId;
        double threshold;

        AccumResConsBranchGenerator(int packSetId_, int resId_, double threshold_) :
            packSetId(packSetId_), resId(resId_), threshold(threshold_) {}
    };

    struct AccumResConsBranchConstraint {
        int id;
        AccumResConsBranchGenerator generator;
        bool greaterOrEqual;

        explicit AccumResConsBranchConstraint(int id_, const AccumResConsBranchGenerator & generator_,
                                              bool greaterOrEqual_) :
            id(id_), generator(generator_), greaterOrEqual(greaterOrEqual_)
        {}
    };

    class AccumResConsBranchingInterface
    {
    protected :
        AccumResConsBranchingInterface() = default;
    public :
        virtual ~AccumResConsBranchingInterface() = default;

        /// Finds at most maxNumCandidates or accum. res. cons. branching generators with the violation closest to 0.5
        virtual bool separate(const FractionalMasterSolution & fracMasterSol, int maxNumCandidates,
                              std::vector<const AccumResConsBranchGenerator *> & generatorPts) const = 0;

        /// For a accum. res. cons. branching generator, returns the total values of paths
        /// satifying the corresponding "greater or equal" constraint
        virtual double violation(const FractionalMasterSolution & fracMasterSol,
                                 const AccumResConsBranchGenerator & generator) const = 0;

        /// Returns true if and only if the path satisifies the constraint
        virtual bool satisfies(const Solution * solPtr, const AccumResConsBranchConstraint * constraint) const = 0;
    };

    /// Creates and prepares packing sets based accumulated resource consumption branching.
    /// Returns nullptr if an error occured.
    AccumResConsBranchingInterface * createAndPrepareAccumResConsBranching(const std::vector<const GraphData *> & graphs,
                                                                           int resId, int printLevel = 0);

    struct RyanFosterBranchGenerator {
        bool basedOnPackingSets;
        int firstSetId;
        int secondSetId;

        RyanFosterBranchGenerator(bool basedOnPackingSets_, int firstSetId_, int secondSetId_) :
                basedOnPackingSets(basedOnPackingSets_), firstSetId(firstSetId_), secondSetId(secondSetId_)
        {}
    };

    struct RyanFosterBranchConstraint {
        int id;
        RyanFosterBranchGenerator generator;
        bool together;

        explicit RyanFosterBranchConstraint(int id_, const RyanFosterBranchGenerator & generator_, bool together_) :
                id(id_),  generator(generator_), together(together_)
        {}
    };

    class RyanFosterBranchingInterface
    {
    protected :
        RyanFosterBranchingInterface() = default;
    public :
        virtual ~RyanFosterBranchingInterface() = default;

        /// Finds at most maxNumCandidates or Ryan&Foster branching generators with the violation closest to 0.5
        virtual bool separate(const FractionalMasterSolution & fracMasterSol, int maxNumCandidates,
                              std::vector<const RyanFosterBranchGenerator *> & generatorPts) const = 0;

        /// For a Ryan&Foster branching generator, returns the total values of paths satifying the corresponding
        /// "together" constraint
        virtual double violation(const FractionalMasterSolution & fracMasterSol,
                                 const RyanFosterBranchGenerator & generator) const = 0;

        /// Returns true if and only if the path satisifies the constraint
        virtual bool satisfies(const Solution * solPtr, const RyanFosterBranchConstraint * constrPtr) const = 0;
    };

    /// Creates and prepares Ryan&Foster branching. Returns nullptr if an error occured.
    RyanFosterBranchingInterface * createAndPrepareRyanFosterBranching(const std::vector<const GraphData *> & graphs,
                                                                       bool usePackingSets = true, int printLevel = 0);

    class SolverRecord {
    protected :
        SolverRecord() = default;
    public :
        virtual ~SolverRecord() = default;
    };

    class LabelExtensionCostFunctor
    {
    public:
        LabelExtensionCostFunctor() = default;
        virtual ~LabelExtensionCostFunctor() = default;
        virtual double getResConsDependentCost(int arcId, const std::vector<double> & resConsumption,
                                               bool isTailResCons) const = 0;
    };

    class FeasibilityCheckFunctor
    {
    public:
        FeasibilityCheckFunctor() = default;
        virtual ~FeasibilityCheckFunctor() = default;
        virtual bool isFeasible(const Solution & solution) const = 0;
    };

    class SolverInterface {
    protected :
        /// Instead of the constructor, the user should call functions createAndPrepareSolver()
        /// or createAndRunFromFile() below
        SolverInterface() = default;
    public :
        virtual ~SolverInterface() = default;

        /// Records and returns the solver state. Should be called before branching.
        virtual SolverRecord * saveToRecord() = 0;

        /// Restores the solver state. Should be called after backtracking in the branch-and-bound tree.
        /// Should also be called just after branching if non-robust branching constraints are added
        /// Vectors of branching constraints should contain all active constraints, not only just added ones.
        /// Returns false if an error occurred, returns true if restoration completed successfully.
        virtual bool restoreFromRecord(const SolverRecord * recordPtr, bool checkDebugSolution,
                                       const std::vector<const AccumResConsBranchConstraint *> & accumResConsBranchCtrPts,
                                       const std::vector<const RyanFosterBranchConstraint *> & ryanFosterBranchCtrPts) = 0;

        /// Returns false if the solver execution was interrupted.
        /// In this case, either the rollback should be performed (output.shouldPerformRollback = true)
        /// or the column generation procedure should be interrupted (output.shouldPerformRollback = false).
        /// Returns true if solver terminated normally.
        /// In this case, the number of returned paths can be zero meaning that the current subproblem is infeasible.
        /// Keep in mind that infeasibility may be caused by reduced cost fixing or enumeration,
        /// and does not necessarily mean that the original subproblem is infeasible.
        virtual bool runPricing(const SolverInput & input, SolverOutput & output) = 0;

        /// Returns false if en error occured during reduced cost fixing or enumeration.
        /// In this case, the BCP algorithm should be interrupted.
        virtual bool runRedCostFixingAndEnumeration(const SolverInput & input, int enumerationMode) = 0;

        /// Returns true if all feasible paths are enumerated and the pricing problem is solved by inspection,
        /// false otherwise. Paths can be already enumerated, but the enumerated status can be false if the pricing
        /// by inspection takes much larger time than standard pricing
        virtual bool getEnumeratedStatus() = 0;

        /// Returns a non-negative number of enumerated feasible paths (even if pricing by inspection takes large
        /// time). Returns -1, if feasible paths are not enumerated.
        virtual int getNumberOfEnumeratedSolutions() = 0;

        /// Returns false if an error occurred, true otherwise.
        /// Returns at most maxNumberOfPaths paths with the smallest reduced cost in "paths".
        /// Returns reduced costs of paths in "costs".
        /// If maxNumberOfPaths is negative, returns all enumerated paths in "paths" without computing and returning
        /// their reduced costs
        /// The ownership of every returned path should be passed somewhere, or the path should be destroyed
        virtual bool getEnumeratedSolutions(const SolverInput & input, int maxNumberOfSols,
                                            std::vector<Solution *> & solPts, std::vector<double> & costs) = 0;

        /// Returns false if en error occured, true otherwise.
        /// In the case the solver is in enumerated state, this function checks which paths are among enumerated paths
        /// and which are not, the result is returned in pathIsEnumerated
        /// This function is used to check which columns should be kept in master when a subproblem passes
        /// to the enumerated state
        virtual bool checkEnumeratedSolutions(const std::vector<const Solution *> & solPts,
                                              std::vector<bool> & solIsEnumerated) const = 0;

        /// Returns true if and only if the path is proper (every elementarity set is visited at most once)
        virtual bool isProper(const Solution & solution) = 0;

        /// Returns true if and only if the path satisfies current NG-neighbourhoods
        virtual bool satisfiesCurrentRelaxation(const Solution & solution) = 0;

        /// Returns true if and only if neighbourhoods were increased
        virtual bool augmentNGneighbourhoods(const FractionalMasterSolution & fracMasterSol) = 0;

        /// Returns true if and only if neighbourhoods were decreased
        /// Attention! Reduction of NG neighbourhoods keeps the overall approach exact only if the current
        /// dual solution is optimal.
        virtual bool reduceNGneighbourhoods(const SolverInput & input) = 0;

        /// returns false if an error occurred, returns true if the termination completed successfully
        virtual bool columnGenerationTerminated(bool afterRedCostFixing,  int nodeOrder, int nodeDepth, int cutSepRound,
                                                double dualBound, double elapsedTime, bool masterConverged,
                                                bool & softTimeLimitIsReached) = 0;

        /// draws solution in DOT format to file with name "filename"
        virtual void drawMasterSolutionInDotFile(const FractionalMasterSolution & fracMasterSol,
                                                 const std::string & fileName) = 0;

        /// return false if an error occured
        virtual bool getDebugSolutions(std::vector<Solution *> & solPts) = 0;

        /// return false if an solution is not correct
        virtual bool setDebugPaths(const std::vector<std::vector<int> > & ids, bool vertexBased) = 0;
    };

    /// Returns the pointer to the solver if its creation and preparation succeeds, returns NULL otherwise;
    /// We either pass the ownership of all functors (callbacks) contained in data to the solver,
    /// or we destroy these functors.
    SolverInterface * createAndPrepareSolver(Data & data);

    /// Returns the pointer to the "meta-solver" (2nd generation solver).
    SolverInterface * createAndPrepareMetaSolver(Data & data);

    /// Creates the solver, runs it once using the pricing data in the file (reduced subset of arcs, reduced costs, etc.),
    /// and then destroys the solver. Returns true if and only if creation and running is successful.
    /// Functors (callbacks) passed in data are not used, their ownership is not changed.
    bool createAndRunFromFile(const Data & data, const std::string & fileName, int colGenPhase);

    /// auxiliary function to round values in primal and dual solutions (to avoid non-deterministic behavior)
    inline double roundP(double d) { return (floor(d * 100000000 + 0.5) / 100000000); }
}


#endif
