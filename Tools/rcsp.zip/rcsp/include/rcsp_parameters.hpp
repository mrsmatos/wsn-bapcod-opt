/**
 * Resource Constrained Shortest Path Solver
 * Designed to be used by Branch-Cut-and-Price algorithms
 *
 * @author Ruslan Sadykov <Ruslan.Sadykov@inria.fr>,
 *
 * Inria, France, All Rights Reserved. [LICENCE]
 */


#ifndef RCSP_PARAMETERS_HPP_
#define RCSP_PARAMETERS_HPP_

#include <string>

namespace bcp_rcsp {

#define RCSP_INFINITY 1e12
#define RCSP_PRECISION 1e-6
#define RCSP_ULP_ABS_PRECISION_FOR_COMPARISON 1e6

#define MAX_NUMBER_OF_ELEMENTARITY_SETS 1024
#define MAX_NUMBER_OF_VERTICES 1024
#define RANK1_CUTS_MAX_NUMBER_OF_ROWS 8

/// number of integers allocated to set based cuts states in labels
/// (number of bits is LIM_MEM_SBCUTS_LABEL_SIZE * 32)
#define LIM_MEM_SBCUTS_LABEL_SIZE 20
#define FULL_MEM_SBCUTS_LABEL_SIZE 60
/// number of bits allocated to NG relaxation states in labels
#define NGRELAX_LABEL_SIZE 16

/// values for the "memoryType" parameter
#define RANK1_AUTOMATIC_MEMORY_SEPARATION 0
#define RANK1_ARC_MEMORY_SEPARATION 1
#define RANK1_VERTEX_MEMORY_SEPARATION 2
#define RANK1_FULL_MEMORY_SEPARATION 3

/// values for the "arcMemoryType" parameter
#define ADD_ONLY_LOOP_ARCS 0       /// smallest arc memory + loop arcs
#define ADD_ALSO_CONNECTING_ARCS 1 /// smallest arc memory + loop arcs + arcs connecting row sets
#define ADD_ALL_ARCS_IN_ROW_SET  2 /// smallest arc memory + loop arcs + all arcs in the row set

/// values for the "dynamicNGmode" parameter
#define DYNAMIC_NG_MODE_NONE 0
#define DYNAMIC_NG_MODE_VERTEX 1
#define DYNAMIC_NG_MODE_ARC 2

/// values for the "applyReducedCostFixing" parameter
#define RCSP_NO_REDUCED_COST_FIXING 0
#define RCSP_NORMAL_REDUCED_COST_FIXING 1 /// normal bucket arc elimination (finding a pair for each label)
#define RCSP_LIGHT_REDUCED_COST_FIXING 2 /// fast bucket arc elimination (based on bucket bounds only)
#define RCSP_NORMAL_REDUCED_COST_FIXING_OF_ORIGINAL_ARCS 3 /// normal arc elimination ("Irnich"-style)
#define RCSP_LIGHT_REDUCED_COST_FIXING_OF_ORIGINAL_ARCS 4 /// fast arc elimination ("Irnich"-style), and based on
                                                          /// on bucket bounds only

/// values for the "useBidirectSearchInPricing" parameter
#define RCSP_MONODIR_SEARCH 0
#define RCSP_BIDIR_SEARCH 1
#define RCSP_EXACT_ONLY_BIDIR_SEARCH 2

/// values for the "useBidirectSearchInEnumeration" parameter
#define RCSP_MONODIR_ENUM_SEARCH 0
#define RCSP_BIDIR_ENUM_SEARCH 1

/// values for the "dynamicBucketSteps" parameter
#define STATIC_BUCKET_STEPS 0
#define AGGREGATED_DYNAMIC_BUCKET_STEPS 1
#define VERTEX_SPECIFIC_DYNAMIC_BUCKET_STEPS 2

/// values for the "useCompletionBoundsInPricing" and "useComplBoundsInRedCostFixing" parameters
#define DO_NOT_USE_COMPLETION_BOUNDS 0
#define USE_STANDARD_COMPLETION_BOUNDS 1
#define USE_EXACT_COMPLETION_BOUNDS 2

/// values for the "shrinkingPolicy" parameter
#define FIRST_SHRINKING_POLICY 0
#define BEST_SHRINKING_POLICY 1

/// values for the "greedyConstructionPolicy" parameter
#define LYSGAARD_GREEDY_CONSTRUCTION_POLICY 0
#define RALPHS_GREEDY_CONSTRUCTION_POLICY 1

/// values for the "cutsTypeToSeparate" parameter
#define SEPARATE_ALL_CUTS 0
#define SEPARATE_ONLY_PACKING_CUTS 1
#define SEPARATE_ONLY_COVERING_CUTS 2

/// values for the "labelSplitStrategy" parameter
#define NO_SPLIT 0
#define LINEAR_PIECE_SPLIT 1
#define BUCKET_SPLIT 2

    struct RoundCapCutsSeparatorParameters {
        int maxNumPerRound;
        int twoPathCutsMaxSubset;
        int twoPathCutsPulseNumSteps;
        bool equalityCase;
        int printLevel;
        double cutViolationTolerance;
        int maxSuperVertexSize;
        int shrinkingPolicy;
        int greedyConstructionPolicy;
        double shrinkingThreshold; /// shrinking is used only if the threshold is positive
        bool useGlobalPoolGreedySearch;
        int routeBasedHeuristicMaxRemovals;

        RoundCapCutsSeparatorParameters() :
            maxNumPerRound(100),
            twoPathCutsMaxSubset(15),
            twoPathCutsPulseNumSteps(10),
            equalityCase(true),
            printLevel(-1),
            cutViolationTolerance(0.02),
            maxSuperVertexSize(1000000),
            shrinkingPolicy(BEST_SHRINKING_POLICY), // former default: FIRST_SHRINKING_POLICY
            greedyConstructionPolicy(LYSGAARD_GREEDY_CONSTRUCTION_POLICY),
            shrinkingThreshold(1.0),
            useGlobalPoolGreedySearch(true),
            routeBasedHeuristicMaxRemovals(1000)
        {}
    };

    struct StrongKPathSeparatorParameters {
        int maxNumPerRound;
        int twoPathCutsMaxSubset;
        int twoPathCutsPulseNumSteps;
        bool equalityCase;
        int printLevel;
        double cutViolationTolerance;
        int routeBasedHeuristicMaxRemovals;

        StrongKPathSeparatorParameters() :
                maxNumPerRound(100),
                twoPathCutsMaxSubset(15),
                twoPathCutsPulseNumSteps(10),
                equalityCase(true),
                printLevel(-1),
                cutViolationTolerance(RCSP_PRECISION),
                routeBasedHeuristicMaxRemovals(1000)
        {}
    };

    struct RouteLoadKnapsackCutsSeparatorParameters {
        int maxNumPerRound;
        bool separateByRounding;
        int oneKSeparation; /// K = 0 - separation only by Chvatal-Gomory rounding,
                            /// K = 6, 8, 10 - separation of up to 1/K-inequalities by the Chopra et al. approach
        double cutViolationTolerance;
        int printLevel;

        RouteLoadKnapsackCutsSeparatorParameters() :
                maxNumPerRound(100),
                separateByRounding(true),
                oneKSeparation(10),
                cutViolationTolerance(0.02),
                printLevel(-1)
        {}
    };

    struct LimMemRankOneCutsSeparatorParameters {
        int maxNumRows;
        int maxNumPerRound;
        int memoryType;
        int arcMemoryType;
        bool spDependentMemory;
        int numLocSearchIterations;
        bool useLocSearchOnlyForSixRowsAndMore;
        int neighbourhoodSize;
        int maxNumTriplets;
        double cutViolationTolerance;
        int printLevel;
        bool writeFracSolInfoToFile;
        bool generateAllFourAndFiveRowCuts; /// if false then 4-row and 5-row cuts are not generated if "projected"
                                            /// violated cuts with smaller number of rows exist
        int cutsTypeToSeparate;
        bool useCoveringSetsForSeparatingOneRowPackingCuts; /// can be set to true if we cannot visit the same
                                                            /// covering set more than once in the same route
                                                            /// this is the case for example for the SDVRP

        LimMemRankOneCutsSeparatorParameters() :
            maxNumRows(5),
            maxNumPerRound(100),
            memoryType(RANK1_VERTEX_MEMORY_SEPARATION),
            arcMemoryType(ADD_ALL_ARCS_IN_ROW_SET),
            spDependentMemory(false),
            numLocSearchIterations(1000),
            useLocSearchOnlyForSixRowsAndMore(false),
            neighbourhoodSize(16),
            maxNumTriplets(10000),
            cutViolationTolerance(0.02),
            printLevel(-1),
            writeFracSolInfoToFile(false),
            generateAllFourAndFiveRowCuts(true),
            cutsTypeToSeparate(SEPARATE_ALL_CUTS),
            useCoveringSetsForSeparatingOneRowPackingCuts(false)
        {}
    };


    struct SolverParameters
    {
        bool checkDominInOtherBuckets;
        int useBidirectSearchInPricing;
        int useBidirectSearchInEnumeration;
        int useCompletionBoundsInPricing;
        double domChecksThresholdInPricing;
        double stopCutGenTimeThresholdInPricing;
        double hardTimeThresholdInPricing;
        double redCostFixingTimeThreshold;
        int maxNumOfColsPerIteration;
        int maxNumOfColsPerExactIteration;
        bool allowRoutesWithSameVerticesSet;
        int heurLabelingStrategy;
        int labelSplitStrategy;
        int numberOfBucketsPerVertex;
        int dynamicBucketSteps;
        double dynBuckStepAdjustRatioThreshold;
        double dynBuckStepAdjustNumBuckArcsThreshold;
        int applyReducedCostFixing;
        double redCostFixingFalseGap;
        int useComplBoundsInRedCostFixing;
        int maxNumOfColumnsInDSSR;
        int maxCycleSizeInDSSR;
        int dynamicNGmode;
        int maxNumOfColumnsInDynamicNG;
        int maxCycleSizeInDynamicNG;
        int initNGneighbourhoodSize;
        int maxNGneighbourhoodSize;
        int maxNGaverNeighbourhoodSize;
        bool useExactComplBoundsInEnumeration;
        int maxNumOfLabelsInEnumeration;
        int maxNumOfLabelsInHeurEnumeration;
        int maxNumOfEnumeratedSolutions;
        double stopRatioForConcatenationInEnum;
        bool generatePosRedCostPaths;
        double toleranceInDSSR;
        bool imposeDiscreteCase;
        bool useMoreTimers;
        int printLevel;
        bool imposeSameResConsumptionInBucketCase; /// sometimes this case is tricky to detect : we need to verify that
                                                   /// every bucket is reached by paths with the same resource
                                                   /// consumption; if user can prove this, he can impose this case
                                                   /// (USE WITH CAUTION!!!)
        bool useVertexIdsInEnumeration; /// in enumeration, label domination is performed using vertex iDs,
                                        /// and not elem. set iDs, for advanced use (USE WITH CAUTION!!!)
        std::string standaloneRCSPfileName;

        SolverParameters() :
            checkDominInOtherBuckets(true),
            useBidirectSearchInPricing(RCSP_EXACT_ONLY_BIDIR_SEARCH),
            useBidirectSearchInEnumeration(RCSP_BIDIR_ENUM_SEARCH),
            useCompletionBoundsInPricing(DO_NOT_USE_COMPLETION_BOUNDS),
            domChecksThresholdInPricing(1e15),
            stopCutGenTimeThresholdInPricing(10.0),
            hardTimeThresholdInPricing(20.0),
            redCostFixingTimeThreshold(100.0),
            maxNumOfColsPerIteration(30),
            maxNumOfColsPerExactIteration(150),
            allowRoutesWithSameVerticesSet(true),
            heurLabelingStrategy(0),
            labelSplitStrategy(NO_SPLIT),
            numberOfBucketsPerVertex(25),
            dynamicBucketSteps(AGGREGATED_DYNAMIC_BUCKET_STEPS),
            dynBuckStepAdjustRatioThreshold(50.0),
            dynBuckStepAdjustNumBuckArcsThreshold(10000),
            applyReducedCostFixing(RCSP_NORMAL_REDUCED_COST_FIXING),
            redCostFixingFalseGap(0.0),
            useComplBoundsInRedCostFixing(USE_EXACT_COMPLETION_BOUNDS),
            maxNumOfColumnsInDSSR(100),
            maxCycleSizeInDSSR(5),
            dynamicNGmode(DYNAMIC_NG_MODE_VERTEX),
            maxNumOfColumnsInDynamicNG(100),
            maxCycleSizeInDynamicNG(5),
            initNGneighbourhoodSize(8),
            maxNGneighbourhoodSize(8),
            maxNGaverNeighbourhoodSize(8),
            useExactComplBoundsInEnumeration(true),
            maxNumOfLabelsInEnumeration(1000000),
            maxNumOfLabelsInHeurEnumeration(0),
            maxNumOfEnumeratedSolutions(1000000),
            stopRatioForConcatenationInEnum(30),
            generatePosRedCostPaths(true),
            toleranceInDSSR(1e-6),
            imposeDiscreteCase(false),
            useMoreTimers(false),
            printLevel(-1),
            imposeSameResConsumptionInBucketCase(false),
            useVertexIdsInEnumeration(false)
        {}
    };

}

#endif
