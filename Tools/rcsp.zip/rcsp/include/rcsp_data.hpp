/**
 * Resource Constrained Shortest Path Solver
 * Designed to be used by Branch-Cut-and-Price algorithms
 *
 * @author Ruslan Sadykov <Ruslan.Sadykov@inria.fr>,
 *
 * Inria, France, All Rights Reserved. [LICENCE]
 */


#ifndef RCSP_DATA_HPP_
#define RCSP_DATA_HPP_

#include <unordered_map>
#include <utility>
#include <vector>
#include <climits>
#include "rcsp_parameters.hpp"

namespace bcp_rcsp
{
    /// convention: if size is 0, not defined;
    ///             if size is 1, linear function (initValue, slope);
    ///             if size is >= 2, PWL function (y, x_0), (slope_1, x_1), ...., (slope n, x_n)
    typedef std::vector<std::pair<double,double> > PieceWiseLinearFunction;

    struct ResourceData
    {
        enum ResourceType { Main, SecondaryDisposable, SecondaryNonDisposable, Base, Dependent, Selection};
        int id;
        ResourceType type;
        double step; /// only relevant for main resources
        std::vector<int> associatedVarIds; /// size of this array determines the number of values for a selection res.,
                                           /// for other resource types, at most one associate variable can be defined
        int baseResId; /// only relevant for dependent resources
        PieceWiseLinearFunction initAccumResConsFunction; /// only relevant for dependent resources

        explicit ResourceData(int id_) :
            id(id_), type(Main), step(0.0), associatedVarIds(), baseResId(-1), initAccumResConsFunction()
        {}
    };

    struct VertexData
    {
        int id;
        std::vector<int> elemSetIds; /// all vectors of set ids
        std::vector<int> packSetIds; /// -- should not contain duplicates
        std::vector<int> covSetIds;  /// -- should be sorted in increasing order
        std::vector<int> enumElemSetIds; /// additional elem. sets which are used only for enumeration
        std::unordered_map<int, double> accumResConsumptionLB; /// for standard and base resources
        std::unordered_map<int, double> accumResConsumptionUB; /// for standard and base resources
        std::unordered_map<int, std::pair<int, int> > accumBinResConsBounds;
        std::unordered_map<int, std::vector<int>> incompatibleValuesForSelection; /// select.res.id -> vector of values
        std::vector<int> ngNeighbourhood;
        std::string name;

        explicit VertexData(int id_) :
            id(id_), elemSetIds(), packSetIds(), covSetIds(), accumResConsumptionLB(), accumResConsumptionUB(),
            accumBinResConsBounds(), ngNeighbourhood(), name()
        {}
    };

    struct ArcData
    {
        int id;
        int tailVertexId;
        int headVertexId;
        double pureCost;
        std::vector<int> elemSetIds; /// all vectors of set ids
        std::vector<int> packSetIds; /// -- should not contain duplicates
        std::vector<int> covSetIds;  /// -- should be sorted in increasing order
        std::vector<int> enumElemSetIds; /// additional elem. sets which are used only for enumeration
        std::unordered_map<int, double> accumResConsumptionLB; /// for standard and base resources
        std::unordered_map<int, double> accumResConsumptionUB; /// for standard and base resources
        std::unordered_map<int, double> resConsumption; /// for standard resources only
        std::unordered_map<int, int> binaryResConsumption;
        std::unordered_map<int, std::vector<int>> incompatibleValuesForSelection; /// select.res.id -> vector of values
        std::unordered_map<int, std::pair<double, double>> varIdToCostAndCoeff; /// varId -> (varCost, varCoeff)
        /// vector of alternative mappings with the same structure as varIdToCostAndCoeff, which is the first mapping
        /// the reduced cost of the arc is set to the minimum reduced cost among all possible mappings
        std::vector<std::unordered_map<int, std::pair<double, double>>> alternativeMappings;
        std::vector<int> ngNeighbourhood;
        std::unordered_map<int, double> depResWaitingTimeCoeff; /// for dependent resources only
        std::unordered_map<int, PieceWiseLinearFunction> resConsumptionPWLfunction; /// for base and dependent resources
        std::unordered_map<int, PieceWiseLinearFunction> accumResConsPWLlowerBoundFunction; /// for dep. resources only
        std::unordered_map<int, PieceWiseLinearFunction> accumResConsPWLupperBoundFunction; /// for dep. resources only
        std::string name;

        explicit ArcData(int id_) :
            id(id_), tailVertexId(-1), headVertexId(-1), pureCost(0.0)
        {}
    };

    struct PreprocessedGraphInfoInterface
    {
    protected:
        PreprocessedGraphInfoInterface() = default;
    public:
        virtual ~PreprocessedGraphInfoInterface() = default;
    };

    struct Solution;

    struct GraphData
    {
        int id;
        int nbElementaritySets;
        int nbPackingSets;
        int nbCoveringSets;
        int sourceVertexId;
        int sinkVertexId;
        std::vector<int> nonDisposableBinaryResIds;
        std::vector<std::vector<double> > elemSetsDistanceMatrix;
        std::vector<std::vector<int> > packSetNeighbourhoodForRank1CutSeparation;
        std::vector<std::tuple<int, int, bool> > permanentRyanFosterConstraints;
        std::vector<ResourceData> resources;
        std::vector<VertexData> vertices;
        std::vector<ArcData> arcs;
        const PreprocessedGraphInfoInterface * preprInfoPtr;

        explicit GraphData(int id_, int nbElementaritySets_ = 0, int nbPackingSets_ = 0, int nbCoveringSets_ = 0) :
            id(id_), nbElementaritySets(nbElementaritySets_), nbPackingSets(nbPackingSets_),
            nbCoveringSets(nbCoveringSets_), sourceVertexId(-1), sinkVertexId(-1), nonDisposableBinaryResIds(),
            elemSetsDistanceMatrix(), packSetNeighbourhoodForRank1CutSeparation(), resources(), vertices(), arcs(),
            preprInfoPtr(nullptr)
        {}

        ~GraphData()
        {
            delete preprInfoPtr;
        }

        /// Should always be called before passing the graph to the solver or to a branching, or to a cut separator.
        /// Preprocessed info is used to speed up the calculation inside the solver and separators.
        /// Returns true if graph is well-defined. Returns false if graph definition is not complete.
        bool generatePreprocessedInfo();
        bool obtainVertexIds(const Solution * solPtr, std::vector<int> & vertexIds) const;
        void exportToDot(const std::string & file_name) const;
    };


    struct ColGenPhaseConfig
    {
        bool completeDominanceCheck;
        bool useJumpBucketArcs;
        bool exactPhase;
        long int maxNumLabelsInBucket;

        ColGenPhaseConfig(bool completeDominanceCheck_, bool useJumpBucketArcs_, long int maxNumLabelsInBucket_) :
                completeDominanceCheck(completeDominanceCheck_), useJumpBucketArcs(useJumpBucketArcs_),
                exactPhase(useJumpBucketArcs_ && completeDominanceCheck_ && (maxNumLabelsInBucket_ == LONG_MAX)),
                maxNumLabelsInBucket(maxNumLabelsInBucket_)
        {
        }
    };

    class LabelExtensionCostFunctor;

    class FeasibilityCheckFunctor;

    class SolverInterface;

    struct Data
    {
        const GraphData & graph;
        SolverParameters params;
        std::vector<ColGenPhaseConfig> colGenPhasesConfig;

        /// Ownership of all pointers below belongs to SolverData
        /// When using SolverData for creation and preparation of the solver,
        /// the ownership passes to the solver, and the pointers are nullified
        LabelExtensionCostFunctor * labelExtensionCostFunctorPtr; /// acc. res. cons. dependent arc cost (used only
                                                                  /// by the historic solver in the discrete case)
        FeasibilityCheckFunctor * feasibilityCheckFunctorPtr;     //// callback to check the feasibility of the
                                                                  ///  RCSP solution (for the case the defined RCSP
                                                                  /// is a relaxation); solution paths, infeasible
                                                                  /// according to this functor, are removed from the
                                                                  /// set of enumerated paths (used by the both solvers)
        SolverInterface * verificationSolverPtr;                  /// solver to verify the optimality of the solution
                                                                  /// (used only by the historic solver)

        Data(const GraphData & graph_, SolverParameters params_) :
            graph(graph_), params(std::move(params_)), colGenPhasesConfig(), labelExtensionCostFunctorPtr(nullptr),
            feasibilityCheckFunctorPtr(nullptr), verificationSolverPtr(nullptr)
        {}
    };
}

#endif
